import httpx
import asyncio
import re
from ddgs import DDGS
from urllib.parse import quote, urlparse, urlunparse

# -------------------------
# links relacionados ao gdrive
# -------------------------

headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
}

def extract_drive_info(url):
    patterns = [
        (r"/file/d/([^/]+)", "file"),
        (r"/drive/folders/([^/?]+)", "folder"),
        (r"id=([^&]+)", "file")
    ]

    for pattern, tipo in patterns:
        match = re.search(pattern, url)
        if match:
            return {
                "id": match.group(1),
                "type": tipo
            }
    return None

# -------------------------
# fixa a url
# -------------------------

def fix_archive_url(url: str):
    try:
        parsed = urlparse(url)

        # pega o caminho e corrige +
        path = parsed.path.replace("+", " ")

        # encode correto (preserva /)
        fixed_path = quote(path, safe="/")

        return urlunparse((
            parsed.scheme,
            parsed.netloc,
            fixed_path,
            parsed.params,
            parsed.query,
            parsed.fragment
        ))
    except Exception as e:
        print("Fix archive error:", e)
        return url

# -------------------------
# pega os arquivos
# -------------------------

async def get_archive_files(identifier: str):
    try:
        url = f"https://archive.org/metadata/{identifier}"

        async with httpx.AsyncClient(headers=headers, timeout=8.0) as client:
            r = await client.get(url)
            data = r.json()

        files = data.get("files", [])

        results = []

        for f in files:
            name = f.get("name", "")

            if name.endswith((".pdf", ".epub", ".mobi")):
                file_url = f"https://archive.org/download/{identifier}/{quote(name)}"

                results.append({
                    "name": name,
                    "url": file_url
                })

        return results

    except Exception as e:
        print("File fetch error:", e)
        return []

# -------------------------
# ANALISADOR
# -------------------------

def analyze_result(r):
    url = r.get("url") or ""

    if "archive.org" in url:
        url = fix_archive_url(url)
        r["url"] = url

    if r.get("download"):
        r["download"] = fix_archive_url(r["download"])

    if r.get("files"):
        for f in r["files"]:
            f["url"] = fix_archive_url(f["url"])
    
        # GOOGLE DRIVE
    if "drive.google.com" in url:
        r["is_drive"] = True
        info = extract_drive_info(url)

       

        

        if info:
            file_id = info["id"]
            tipo = info["type"]

            r["drive_type"] = tipo
            r["is_drive_folder"] = r.get("drive_type") == "folder"
            r["is_drive_file"] = r.get("drive_type") == "file"

            if tipo == "file":
                r["drive_preview"] = f"https://drive.google.com/file/d/{file_id}/preview"
                r["drive_download"] = f"https://drive.google.com/uc?export=download&id={file_id}"

            elif tipo == "folder":
                r["drive_folder"] = f"https://drive.google.com/drive/folders/{file_id}"

    else:
        r["is_drive"] = False

    keywords = ["book", "livro", "ebook", "pdf", "epub", "mobi"]

    title = (r.get("title") or "").lower()
    url = (r.get("url") or "").lower()

    r["is_book"] = any(k in title or k in url for k in keywords)
    r["is_pdf"] = url.endswith(".pdf") or ".pdf" in url
    r["is_epub"] = ".epub" in url


    return r


# -------------------------
# DuckDuckGo (com dorks)
# -------------------------
async def ddg_search(query: str):
    return await asyncio.to_thread(_ddg_sync, query)

def _ddg_sync(query):
    results = []

    dorks = [
        query,
        f"{query} pdf",
        f"{query} epub",
        f"{query} filetype:pdf"
    ]

    with DDGS() as ddgs:
        for dork in dorks:
            for r in ddgs.text(dork, max_results=5):
                results.append({
                    "title": r.get("title"),
                    "url": r.get("href"),
                    "snippet": r.get("body"),
                    "source": "duckduckgo"
                })

    return results


# -------------------------
# OpenLibrary (metadata)
# -------------------------
async def openlibrary_search(query: str):
    url = "https://openlibrary.org/search.json"

    async with httpx.AsyncClient(headers=headers, timeout=8.0) as client:
        r = await client.get(url, params={"q": query})
        data = r.json()

    results = []

    for doc in data.get("docs", [])[:10]:
        if "key" in doc:
            results.append({
                "title": doc.get("title"),
                "url": f"https://openlibrary.org{doc['key']}",
                "author": (doc.get("author_name") or [None])[0],
                "year": doc.get("first_publish_year"),
                "source": "openlibrary"
            })

    return results


# -------------------------
# Internet Archive
# -------------------------
async def archive_search(query: str):
    try:
        url = "https://archive.org/advancedsearch.php"

        params = [
            ("q", f'({query}) AND mediatype:texts AND (format:pdf OR format:epub)'),
            ("fl[]", "identifier"),
            ("fl[]", "title"),
            ("fl[]", "creator"),
            ("fl[]", "year"),
            ("rows", 20),
            ("output", "json")
        ]

        async with httpx.AsyncClient(headers=headers, timeout=8.0) as client:
            r = await client.get(url, params=params)
            try:
                data = r.json()
            except:
                return []

        results = []

        docs = data.get("response", {}).get("docs", [])

        tasks = [get_archive_files(d.get("identifier")) for d in docs[:5]]
        files_list = await asyncio.gather(*tasks)

        for d, files in zip(docs[:5], files_list):
            identifier = d.get("identifier")
            title = d.get("title")

            if not identifier or not title:
                continue

            # pega o melhor arquivo (primeiro encontrado)
            download = files[0]["url"] if files else None

            results.append({
                "title": title,
                "url": f"https://archive.org/details/{identifier}",
                "collection": f"https://archive.org/download/{identifier}",
                "download": download,
                "files": files[:5],
                "author": d.get("creator"),
                "year": d.get("year"),
                "source": "archive"
            })

        return results

    except Exception as e:
        print("Archive error:", e)
        return []


# -------------------------
# preview
# -------------------------

async def fetch_preview(url):
    try:
        async with httpx.AsyncClient(
            headers=headers,
            timeout=httpx.Timeout(3.0),  # menor tempo
            follow_redirects=True
        ) as client:
            r = await client.get(url)

            # evita pegar coisa gigante (tipo PDF ou binário)
            content_type = r.headers.get("content-type", "")
            if "text/html" not in content_type:
                return {}

            html = r.text[:3000]

        title = re.search(r"<title[^>]*>(.*?)</title>", html, re.IGNORECASE | re.DOTALL)
        desc = re.search(
            r'<meta name="description" content="(.*?)"',
            html,
            re.IGNORECASE
        )

        return {
            "preview_title": title.group(1).strip() if title else None,
            "preview_desc": desc.group(1).strip() if desc else None
        }

    except httpx.ReadTimeout:
        # timeout é normal, não precisa poluir log
        return {}

    except Exception as e:
        print(f"Preview error: {type(e).__name__}")
        return {}


# -------------------------
# UTIL
# -------------------------
def deduplicate(results):
    seen = set()
    unique = []

    for r in results:
        url = (r.get("url") or "").strip()
        if url and url not in seen:
            seen.add(url)
            unique.append(r)

    return unique


# -------------------------
# AGREGADOR FINAL
# -------------------------
async def search(query: str):

    ddg_task = ddg_search(query)
    openlib_task = openlibrary_search(query)
    archive_task = archive_search(query)

    ddg, openlib, archive = await asyncio.gather(
        ddg_task,
        openlib_task,
        archive_task,
        return_exceptions=True
    )

    # evita crash se alguma falhar
    ddg = ddg if isinstance(ddg, list) else []
    openlib = openlib if isinstance(openlib, list) else []
    archive = archive if isinstance(archive, list) else []

    merged = ddg[:20] + openlib[:10] + archive[:10]

    unique = deduplicate(merged)

    analyzed = [analyze_result(r) for r in unique]

    preview_targets = [
        r for r in analyzed
        if r.get("url")
        and not r.get("is_pdf")
        and "drive.google.com" not in r.get("url", "")
        and "archive.org/download" not in r.get("url", "")
    ][:10]

    preview_tasks = [fetch_preview(r["url"]) for r in preview_targets]

    previews = await asyncio.gather(*preview_tasks, return_exceptions=True)

    for r, p in zip(preview_targets, previews):
        if isinstance(p, dict):
            r.update(p)

    return {
        "query": query,
        "total": len(analyzed),
        "results": analyzed
    }