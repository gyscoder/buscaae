from pydantic import BaseModel
from typing import List, Optional

class SearchParams(BaseModel):
    title: Optional[str] = None
    author: Optional[str] = None
    publisher: Optional[str] = None
    year: Optional[int] = None
    filetypes: Optional[List[str]] = None
    site: Optional[str] = None
    frase: Optional[str] = None