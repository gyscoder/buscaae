from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from app.dork_builder import build_dork
from app.models import SearchParams
from app.search_client import search

app = FastAPI(
    title="Book Dork Search API",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.mount("/frontend", StaticFiles(directory="frontend", html=True), name="frontend")


@app.get("/")
def root():
    return {"status": "online"}


@app.post("/search")
async def search_books(params: SearchParams):

    dork = build_dork(
        title=params.title,
        author=params.author,
        publisher=params.publisher,
        year=params.year,
        filetypes=params.filetypes,
        site=params.site,
        frase=params.frase
    )

    data = await search(dork)

    return data